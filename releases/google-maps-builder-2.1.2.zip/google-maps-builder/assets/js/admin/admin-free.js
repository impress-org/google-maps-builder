/**
 * Admin Free Google Maps
 *
 * @description: Enqueued on the single `google_maps` CPT and responsible for interface map creation
 */
(function ( $, gmb ) {



}( jQuery, window.MapsBuilderAdmin || ( window.MapsBuilderAdmin = {} ) ) );