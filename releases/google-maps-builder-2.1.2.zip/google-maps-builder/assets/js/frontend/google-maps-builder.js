/**
 * Maps Builder JS
 *
 * @description: Frontend form rendering
 */
var gmb_data;

(function ($) {

}(jQuery));